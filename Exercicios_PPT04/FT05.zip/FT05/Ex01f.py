lista=[]

if not len(lista)>0:
    print("A lista está vazía.")
else:
    print("A lista não está vazía.")


lista=[10,15,42]
mult=1

for num in lista:
    mult= mult*num

print(f"Multiplicação dos valores da lista: {mult}")

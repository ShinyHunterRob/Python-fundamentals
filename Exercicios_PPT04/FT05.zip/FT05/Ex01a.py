for num in range(1,51):
    print(num)
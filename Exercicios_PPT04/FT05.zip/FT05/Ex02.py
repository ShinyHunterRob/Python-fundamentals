lista = [142]

lista.insert(0,1);print(lista)
lista.append(3);print(lista)
lista.remove(142);print(lista)
print(len(lista))
lista.clear()
print(lista)
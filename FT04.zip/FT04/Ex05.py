for i in range(1,101,1):
    print(f"{i}")
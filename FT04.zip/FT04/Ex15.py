print ("Múltiplos de 5:\n")

for i in range(1,21,1):
    print(f"{5*i}")
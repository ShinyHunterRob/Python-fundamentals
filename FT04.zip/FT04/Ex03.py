print("Calcular médias de números.")
num1 = int(input("Insira o primeiro número:\t"))
num2 = int(input("Insira o segundo número:\t"))
num3 = int(input("Insira o terceiro número:\t"))
num4 = int(input("Insira o quarto número:\t"))

media = (num1 + num2 + num3 + num4) / 4

print("A média dos números é:", media)
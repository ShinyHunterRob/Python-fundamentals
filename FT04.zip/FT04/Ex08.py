print ("Tabuada do número 5:\n")


for i in range(1,11,1):
    print(f"5 x {i} = {5*i}")
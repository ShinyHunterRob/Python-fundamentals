for i in range(1,101,1):
    print(f"Número: {i} - Quadrado: {i**2}")
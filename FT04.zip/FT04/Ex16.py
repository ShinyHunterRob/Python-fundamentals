num=1

while -1 < num < 11:
    num=int(input("Insira um número entre 0 e 10, inclusive:\t"))
else:
    print("Você inseriu um número fora do intervalo solicitado.")
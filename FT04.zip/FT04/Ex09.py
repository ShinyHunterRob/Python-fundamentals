num = int(input("Insira um número para calcular a sua tabuada:\t"))

for i in range(1,11,1):
    print(f"{num} x {i} = {num*i}")
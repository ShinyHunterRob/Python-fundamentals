num_min = int(input("Insira o limite mínimo:\t"))
num_max = int(input("Insira o limite máximo:\t"))


for i in range(num_min,num_max+1,1):
    print(i)
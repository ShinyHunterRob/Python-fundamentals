print("Soma de todos os números entre 10 e 100:\n")
soma=0

for i in range(10,101,1):
    soma += i
    print(soma)    
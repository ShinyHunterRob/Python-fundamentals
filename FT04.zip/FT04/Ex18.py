for i in range(2,201,2):
    print(f"{i}")